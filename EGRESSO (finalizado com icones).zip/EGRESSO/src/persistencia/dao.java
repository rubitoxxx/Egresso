package persistencia;

import controle.TurmaPK;
import java.util.List;
import javax.persistence.*;

/**
 * Classe DAO para interação com o banco de dados usando JPA (Java Persistence API).
 */
public class dao {

    public static void salvar(Object objeto) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        ent.merge(objeto);  // Usando merge para atualizar ou salvar o objeto
        ent.getTransaction().commit();
    }

    public static List listar(String nomePesquisa) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(nomePesquisa);
        return q.getResultList();
    }

    public static List listar(String nomePesquisa, String parametro, int chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(nomePesquisa);
        q.setParameter(parametro, chave);
        return q.getResultList();
    }

    public static List listar(String nomePesquisa, String parametro, String chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(nomePesquisa);
        q.setParameter(parametro, chave);
        return q.getResultList();
    }

    public static List listar1Sql(String sql) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createQuery(sql);
        return q.getResultList();
    }

    public static int executarSql(String sql) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNativeQuery(sql);
        ent.getTransaction().begin();
        int r = q.executeUpdate();
        ent.getTransaction().commit();
        return r;
    }

    public static void excluir(Object objeto) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        ent.remove(ent.merge(objeto)); // Remove o objeto, garantindo que ele esteja persistido corretamente
        ent.getTransaction().commit();
    }

    public static void excluir(String pesquisa, String parametro, int chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        Object objeto = q.getSingleResult();
        ent.remove(objeto);
        ent.getTransaction().commit();
    }

    public static void excluir(String pesquisa, String parametro, String chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        Object objeto = q.getSingleResult();
        ent.remove(objeto);
        ent.getTransaction().commit();
    }

    public static Object consultar(String pesquisa, String parametro, int chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    public static Object consultar(String pesquisa, String parametro, String chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    public static Object consultar(String pesquisa, String parametro, TurmaPK chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);  // Passa o parâmetro TurmaPK aqui
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    // Método corrigido para consulta de curso por ID Instituição e ID Curso
    public static Object consultar(String pesquisa, String idinstituicao, int chave1, String idcurso, String chave2) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(idinstituicao, chave1);
        q.setParameter(idcurso, chave2);
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    // Exemplo de exclusão usando TurmaPK
    public static void excluir(String pesquisa, String idturma, TurmaPK pk) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(idturma, pk);
        Object objeto = q.getSingleResult();
        ent.remove(objeto);
        ent.getTransaction().commit();
    }

    public static void excluir(String cursofindByIdinstituicaoIdcurso, String idinstituicao, int idinstituicao0, String idcurso, String idcurso0) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}