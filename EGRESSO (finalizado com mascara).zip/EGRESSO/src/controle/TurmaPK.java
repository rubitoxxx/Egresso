package controle;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Representa a chave primária composta de uma turma.
 * 
 * @author Acer
 */
@Embeddable
public class TurmaPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "idinstituicao")
    private int idinstituicao;

    @Basic(optional = false)
    @Column(name = "idcurso")
    private String idcurso;

    @Basic(optional = false)
    @Column(name = "idturma")
    private String idturma;

    public TurmaPK() {
    }

    public TurmaPK(int idinstituicao, String idcurso, String idturma) {
        this.idinstituicao = idinstituicao;
        this.idcurso = idcurso;
        this.idturma = idturma;
    }

    public int getIdinstituicao() {
        return idinstituicao;
    }

    public void setIdinstituicao(int idinstituicao) {
        this.idinstituicao = idinstituicao;
    }

    public String getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(String idcurso) {
        this.idcurso = idcurso;
    }

    public String getIdturma() {
        return idturma;
    }

    public void setIdturma(String idturma) {
        this.idturma = idturma;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) idinstituicao;
        hash += (idcurso != null ? idcurso.hashCode() : 0);
        hash += (idturma != null ? idturma.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof TurmaPK)) {
            return false;
        }
        TurmaPK other = (TurmaPK) object;
        if (this.idinstituicao != other.idinstituicao) {
            return false;
        }
        if ((this.idcurso == null && other.idcurso != null) || (this.idcurso != null && !this.idcurso.equals(other.idcurso))) {
            return false;
        }
        return !((this.idturma == null && other.idturma != null) || (this.idturma != null && !this.idturma.equals(other.idturma)));
    }

    @Override
    public String toString() {
        return "controle.TurmaPK[ idinstituicao=" + idinstituicao + ", idcurso=" + idcurso + ", idturma=" + idturma + " ]";
    }
}