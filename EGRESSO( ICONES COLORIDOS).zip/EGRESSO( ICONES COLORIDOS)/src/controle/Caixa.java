
package controle;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

@Entity
@Table(name = "caixa")
@NamedQueries({
    @NamedQuery(name = "Caixa.pesquisaNome", query = "SELECT p FROM Caixa p WHERE p.idcaixa LIKE :idcaixa"),
    @NamedQuery(name = "Caixa.findAll", query = "SELECT c FROM Caixa c"),
    @NamedQuery(name = "Caixa.findByIdcaixa", query = "SELECT c FROM Caixa c WHERE c.idcaixa = :idcaixa"),
    @NamedQuery(name = "Caixa.findByIdlocal", query = "SELECT c FROM Caixa c WHERE c.idlocal = :idlocal"),
    @NamedQuery(name = "Caixa.findByPrateleira", query = "SELECT c FROM Caixa c WHERE c.prateleira = :prateleira")
})
public class Caixa implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @Column(name = "idcaixa")
    private String idcaixa;

    @Basic(optional = false)
    @Column(name = "idlocal")
    private int idlocal;

    @Basic(optional = false)
    @Column(name = "prateleira")
    private String prateleira;

    public Caixa() {
    }

    public Caixa(String idcaixa) {
        this.idcaixa = idcaixa;
    }

    public Caixa(String idcaixa, int idlocal, String prateleira) {
        this.idcaixa = idcaixa;
        this.idlocal = idlocal;
        this.prateleira = prateleira;
    }

    public String getIdcaixa() {
        return idcaixa;
    }

    public void setIdcaixa(String idcaixa) {
        this.idcaixa = idcaixa;  // Atribuindo o valor ao campo idcaixa
    }

    public int getIdlocal() {
        return idlocal;
    }

    public void setIdlocal(int idlocal) {
        this.idlocal = idlocal;  // Atribuindo o valor ao campo idlocal
    }

    public String getPrateleira() {
        return prateleira;
    }

    public void setPrateleira(String prateleira) {
        this.prateleira = prateleira;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (idcaixa != null ? idcaixa.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Caixa)) {
            return false;
        }
        Caixa other = (Caixa) object;
        return !((this.idcaixa == null && other.idcaixa != null) || (this.idcaixa != null && !this.idcaixa.equals(other.idcaixa)));
    }

    @Override
    public String toString() {
        return "controle.Caixa[ idcaixa=" + idcaixa + " ]";
    }

}