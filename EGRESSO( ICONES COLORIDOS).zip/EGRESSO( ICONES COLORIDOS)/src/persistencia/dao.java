package persistencia;
import controle.CursoPK;
import controle.TurmaPK;
import java.util.List;
import javax.persistence.*;

/**
 * Classe DAO para interação com o banco de dados usando JPA (Java Persistence API).
 */
public class dao {

    public static void salvar(Object objeto) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        ent.merge(objeto);  // Usando merge para atualizar ou salvar o objeto
        ent.getTransaction().commit();
    }

    public static List listar(String nomePesquisa) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(nomePesquisa);
        return q.getResultList();
    }

    public static List listar(String nomePesquisa, String parametro, int chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(nomePesquisa);
        q.setParameter(parametro, chave);
        return q.getResultList();
    }

    public static List listar(String nomePesquisa, String parametro, String chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(nomePesquisa);
        q.setParameter(parametro, chave);
        return q.getResultList();
    }

    public static List listar1Sql(String sql) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createQuery(sql);
        return q.getResultList();
    }
    public static List listarPorNome(String nome) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery("Curso.pesquisaNome");
        q.setParameter("nome", "%" + nome + "%"); // Adiciona os curingas % para busca por parte do nome
        return q.getResultList();
    }
    public static int executarSql(String sql) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNativeQuery(sql);
        ent.getTransaction().begin();
        int r = q.executeUpdate();
        ent.getTransaction().commit();
        return r;
    }

    public static void excluir(Object objeto) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        ent.remove(ent.merge(objeto)); // Remove o objeto, garantindo que ele esteja persistido corretamente
        ent.getTransaction().commit();
    }

    public static void excluir(String pesquisa, String parametro, int chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        Object objeto = q.getSingleResult();
        ent.remove(objeto);
        ent.getTransaction().commit();
    }

    public static void excluir(String pesquisa, String parametro, String chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        Object objeto = q.getSingleResult();
        ent.remove(objeto);
        ent.getTransaction().commit();
    }

    public static Object consultar(String pesquisa, String parametro, int chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    public static Object consultar(String pesquisa, String parametro, String chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    public static Object consultar(String pesquisa, String parametro, TurmaPK chave) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(parametro, chave);  // Passa o parâmetro TurmaPK aqui
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }
    public static Object consultar(String pesquisa, String idinstituicao, int chave1, String idcurso, String chave2, String idturma, String chave3) {
    EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
    Query q = ent.createNamedQuery(pesquisa);
    q.setParameter(idinstituicao, chave1);
    q.setParameter(idcurso, chave2);
    q.setParameter(idturma, chave3);
    try {
        return q.getSingleResult();
    } catch (NoResultException e) {
        return null; // Retorna null caso não encontre nada
    }
}
    
    // Método corrigido para consulta de curso por ID Instituição e ID Curso
    public static Object consultar(String pesquisa, String idinstituicao, int chave1, String idcurso, String chave2) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter(idinstituicao, chave1);
        q.setParameter(idcurso, chave2);
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    public static Object consultar(String pesquisa, TurmaPK pk) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter("idinstituicao", pk.getIdinstituicao());
        q.setParameter("idcurso", pk.getIdcurso());
        q.setParameter("idturma", pk.getIdturma());
        try {
            return q.getSingleResult();
        } catch (NoResultException e) {
            return null; // Retorna null caso não encontre nada
        }
    }

    public static void excluir(String pesquisa, TurmaPK pk) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter("idinstituicao", pk.getIdinstituicao());
        q.setParameter("idcurso", pk.getIdcurso());
        q.setParameter("idturma", pk.getIdturma());
        Object objeto = q.getSingleResult();
        ent.remove(objeto);
        ent.getTransaction().commit();
    }

    public static void excluir(String pesquisa, CursoPK pk) {
        EntityManager ent = Persistence.createEntityManagerFactory("UP").createEntityManager();
        ent.getTransaction().begin();
        Query q = ent.createNamedQuery(pesquisa);
        q.setParameter("idinstituicao", pk.getIdinstituicao());
        q.setParameter("idcurso", pk.getIdcurso());
        Object objeto = q.getSingleResult();
        ent.remove(objeto);
        ent.getTransaction().commit();
    }
}
