package controle;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 * Classe que representa a chave primária composta para a entidade Curso.
 */
@Embeddable
public class CursoPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "idinstituicao")
    private int idinstituicao;
    
    @Basic(optional = false)
    @Column(name = "idcurso")
    private String idcurso;

    // Construtores
    public CursoPK() {
    }

    public CursoPK(int idinstituicao, String idcurso) {
        this.idinstituicao = idinstituicao;
        this.idcurso = idcurso;
    }

    // Getters e Setters
    public int getIdinstituicao() {
        return idinstituicao;
    }

    public void setIdinstituicao(int idinstituicao) {
        this.idinstituicao = idinstituicao;
    }

    public String getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(String idcurso) {
        this.idcurso = idcurso;
    }

    // Métodos hashCode e equals
    @Override
    public int hashCode() {
        int hash = 0;
        hash += idinstituicao;  // Inclui o idinstituicao no cálculo do hash
        hash += (idcurso != null ? idcurso.hashCode() : 0);  // Inclui o idcurso, que pode ser nulo
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof CursoPK)) {
            return false;
        }
        CursoPK other = (CursoPK) object;
        return this.idinstituicao == other.idinstituicao && (this.idcurso != null && this.idcurso.equals(other.idcurso));
    }

    @Override
    public String toString() {
        return "controle.CursoPK[ idinstituicao=" + idinstituicao + ", idcurso=" + idcurso + " ]";
    }
}