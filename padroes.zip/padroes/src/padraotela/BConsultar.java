package padraotela;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
public class BConsultar extends JButton{
 public BConsultar() {
 this.setText("CONSULTAR");
 this.setPreferredSize(new Dimension(110, 30));
 this.setBackground(Color.yellow);
 }
}
