package padraotela;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
public class BExcluir extends JButton{
 public BExcluir() {
 this.setText("EXCLUIR");
 this.setPreferredSize(new Dimension(110, 30));
 this.setBackground(Color.red);
 }
}