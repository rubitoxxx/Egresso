package padraotela;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
public class BLimpar extends JButton{
 public BLimpar() {
 this.setText("LIMPAR");
 this.setPreferredSize(new Dimension(110, 30));
 this.setBackground(Color.white);
 }
}