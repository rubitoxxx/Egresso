package padraotela;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
public class BSair extends JButton{
 public BSair() {
 this.setText("SAIR");
 this.setPreferredSize(new Dimension(110, 30));
 this.setBackground(Color.gray);
 }
}
