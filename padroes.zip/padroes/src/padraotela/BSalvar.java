package padraotela;
import java.awt.Color;
import java.awt.Dimension;
import javax.swing.JButton;
public class BSalvar extends JButton{
 public BSalvar() {
 this.setText("SALVAR");
 this.setPreferredSize(new Dimension(110, 30));
 this.setBackground(Color.green);
 }
}
