package padraotela;
import java.awt.Dimension;
import javax.swing.JLabel;
public class Rotulo extends JLabel{
 public Rotulo () {
 this.setPreferredSize(new Dimension(110, 20));
 this.setText("NOME DO CAMPO");
 }
}